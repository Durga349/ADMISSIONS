<?php 
session_start();

include_once("crudop/crud.php");
$crud = new Crud();
$tableName = 'registration';
$tableName1 = 'login';

$name         = isset($_POST['name'])?trim($_POST['name']):'';
$email        = isset($_POST['email'])?trim($_POST['email']):'';
$psw          = isset($_POST['psw'])?trim($_POST['psw']):'';
$phone        = isset($_POST['phone'])?trim($_POST['phone']):'';
$place        = isset($_POST['place'])?trim($_POST['place']):'';

/*$login_type     = isset($_POST['login_type'])?trim($_POST['login_type']):'';*/

$encpass        = md5($psw);
$randomId       = uniqid(substr(0, 10));

if(isset($_POST['action']) && $_POST['action'] == 'register'){

   $ins_reg = "insert into ".$tableName." set  name = '".$name."', email = '".$email."', psw = '".$psw."', phone = '".$phone."', place = '".$place."', randomId = '".$randomId."' ";
  

$reg_data = $crud->execute($ins_reg);

if($reg_data)
{
   $ins_log = "insert into ".$tableName1." set email = '".$email."', psw = '".$psw."' , encpassword = '".$encpass."', randomId = '".$randomId."' ";

   $log_data = $crud->execute($ins_log);
}

if ($reg_data && $log_data){
    
    echo "true";
     }else{
        echo "false";
        }
}


if(isset($_POST['action']) && $_POST['action'] == 'login'){
  extract($_POST);
  $email = isset($email) ? $email :'';
  $psw = isset($psw) ? $psw : '';

$res_sql = "select * from ".$tableName1." where email = '".$email."' and psw = '".$psw."' and encpassword = '".md5($_POST['psw'])."' ";
  //exit;
  $res_data = $crud->getData($res_sql);


  if (count($res_data) > 0){
    
 $_SESSION['email']        = $res_data[0]['email'];
 

    echo "true";
     }else{
      echo "false";
     }
}
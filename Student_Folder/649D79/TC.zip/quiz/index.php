<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.css" rel="stylesheet"/>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.9/jquery.validate.js"></script>
    <script src="js/vendor/jquery-1.12.4.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <title>Login Page</title>
    <style type="text/css">
        .card{
            background-color: rgb(231, 231, 231);
        }
        .card-title{
            color: #0000ff;
            font-weight: 700;
        }
        #submit{
            background-color: #0000ff;
            color: white;
            font-weight: 700;
        }
        .input-group-text{
            background-color: #0000ff;
        }
        .card{
            margin-top: 100px;
        }
        .error{
            color: red;
        }
    </style>
</head>
<body>
    <form method="post" name="addform" id="addform" enctype="multipart/form-data"  autocomplete="off">
    <div class="container-fluid">
    <div class="row">
        <div class="col-md-4"></div>
        <div class="col-md-4">
    <div class="card">
        <div class="card-body">
        <h2 class="card-title"><center>Login</center></h2>
      <div class="input-group">
        <div class="input-group-prepend">
          <div class="input-group-text">
          <i class="fa-solid fa-user" style="color: #ffffff;"></i>
            </div>
        </div>
        <input type="email" class="form-control" id="email" name="email" placeholder="Username" required>
      </div>
       <div class="input-group mt-3">
        <div class="input-group-prepend">
          <div class="input-group-text">
          <i class="fa-solid fa-lock" style="color: #ffffff;"></i>
            </div>
        </div>
        <input type="password" class="form-control" id="psw" name="psw" placeholder="Password" required>
      </div>
      <div class="text-center mt-2">
	    <a href="quiz_register.php">Create Your Account</a>
	    </div>
		<button name="submit" id="submit" class="form-control mt-3">login</button>
	</div>
	</div>
</div>
</div>
</form>
</body>
</html>
<script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.9/jquery.validate.js"></script>

<script type="text/javascript">

$(function() {

    //alert('jkgh');
   $("form[name='addform']").validate({
    rules: {   
       
       
       email     : "required",
       psw     : "required",
       
        },
    // Specify validation error messages
    messages: {    
       
       
       email     : "Please Enter UserName",
       psw     : "Please Enter Password",
   },
    
    submitHandler: function(form) {
      
        let formdata = new FormData();
        let x = $('#addform').serializeArray();
        $.each(x, function(i, field){
          formdata.append(field.name,field.value);
        });
        formdata.append('action' , 'login');
          
        $.ajax({
          type: "POST",
          url: "saveregister.php",
          enctype: 'multipart/form-data',
          processData: false,
          contentType: false,
          cache: false,
          data: formdata,
          success: function (data) {
            if (data.trim() == 'true'){
              toastr.success('Logined successfully...!');
              setTimeout(function (){
                location.href = "home.php";
              },1000);
            }
            else{
              toastr.error(data);
            }
          }
        });
      }
  });
});

</script>
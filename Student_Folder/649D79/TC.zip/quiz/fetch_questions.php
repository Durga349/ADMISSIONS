<?php
// Assuming you have a database connection already established
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "quiz";

// Create a connection to the database
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Query the database to fetch the questions
$sql = "SELECT * FROM questions";
$result = $conn->query($sql);

$questions = [];

if ($result->num_rows > 0) {
  // Loop through each row and build the questions array
  while ($row = $result->fetch_assoc()) {
    $question = [
      "question" => $row["question"],
       'options' => array($row['option_1'], $row['option_2'], $row['option_3'])
      /*"answer" => $row["answer"]*/
    ];

    $questions[] = $question;
  }
}

// Close the database connection
$conn->close();

// Send the questions as a JSON response
header("Content-Type: application/json");
echo json_encode($questions);
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.css" rel="stylesheet"/>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.3/jquery.validate.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

  <title>Register Page</title>
  <style type="text/css">
    .card {
      background-color: rgb(231, 231, 231);
    }
    .card-title {
      color: #0000ff;
      font-weight: 700;
    }
    #submit {
      background-color: #0000ff;
      color: white;
      font-weight: 700;
    }
    .input-group-text {
      background-color: #0000ff;
    }
    .card {
      margin-top: 100px;
    }
    .error{
      color: red;
    }
  </style>
</head>
<body>
  <form method="post" name="addFormPage" id="addFormPage" autocomplete="off" enctype="multipart/form-data">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-4"></div>
        <div class="col-md-4">
          <div class="card">
            <div class="card-body">
              <h2 class="card-title"><center>Registration</center></h2>
              <div class="input-group">
                <div class="input-group-prepend">
                  <div class="input-group-text">
                    <i class="fa-solid fa-user" style="color: #ffffff;"></i>
                  </div>
                </div>
                <input type="text" class="form-control" id="name" name="name" placeholder="Name" required>
              </div>
              <div class="input-group mt-3">
                <div class="input-group-prepend">
                  <div class="input-group-text">
                    <i class="fa-regular fa-envelope" style="color: #ffffff;"></i>
                  </div>
                </div>
                <input type="email" class="form-control" id="email" name="email" placeholder="Email" required>
              </div>
              <div class="input-group mt-3">
                <div class="input-group-prepend">
                  <div class="input-group-text">
                    <i class="fa-solid fa-key" style="color: #ffffff;"></i>
                  </div>
                </div>
                <input type="password" class="form-control" id="psw" name="psw" placeholder="Password" required>
              </div>
              <div class="input-group mt-3">
                <div class="input-group-prepend">
                  <div class="input-group-text">
                    <i class="fa-solid fa-phone" style="color: #ffffff;"></i>
                  </div>
                </div>
                <input type="text" class="form-control" id="phone" name="phone" placeholder="Phone Number" required>
              </div>
              <div class="input-group mt-3">
                <div class="input-group-prepend">
                  <div class="input-group-text">
                    <i class="fa-solid fa-location-dot" style="color: #ffffff;"></i>
                  </div>
                </div>
                <input type="text" class="form-control" id="place" name="place" placeholder="Place" required>
              </div>
              <button type="submit" name="submit" id="submit" class="btn mt-3 float-right">Register</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </form>
</body>

<script type="text/javascript">
  $(function() {
    $("#addFormPage").validate({
      rules: {
        name: "required",
        email: {
          required: true,
          email: true
        },
        psw: "required",
        phone: "required",
        place: "required",
      },
      messages: {
        name: "Please enter your name",
        email: {
          required: "Please enter your email address",
          email: "Please enter a valid email address"
        },
        psw: "Please enter your password",
        phone: "Please enter your phone number",
        place: "Please enter your place",
      },
      submitHandler: function(form) {
        let formdata = new FormData(form);
        formdata.append('action', 'register');
        $.ajax({
          type: "POST",
          url: "saveregister.php",
          enctype: 'multipart/form-data',
          processData: false,
          contentType: false,
          cache: false,
          data: formdata,
          success: function(data) {
            if (data.trim() == 'true') {
              toastr.success('Saved successfully...!');
              setTimeout(function() {
                location.href = "index.php";
              }, 1000);
            } else {
              toastr.error(data);
            }
          }
        });
      }
    });
  });
</script>
</html>
